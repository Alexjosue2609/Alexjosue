<!DOCTYPE html>

<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="Stylesheet" href="style.css">

    <title>Flower</title>

</head>

<body>



<div class="flower">

    <div class="text-above">Tqm mucho Alejitapp</div>

    <div class="mid">

    </div>

    <div class="Petal1 p1">

    </div>

    <div class="Petal1 p2">

    </div>

    <div class="Petal1 p3">

    </div>

    <div class="Petal1 p4">

    </div>

    <div class="Petal2 p1">

    </div>

    <div class="Petal2 p2">

    </div>

    <div class="Petal2 p3">

    </div>

    <div class="Petal2 p4">

    </div>

    <div class="Petal3 p1">

    </div>

    <div class="Petal3 p2">

    </div>

    <div class="Petal3 p3">

    </div>

    <div class="Petal3 p4">

    </div>

    <div class="text-below">Feliz primaveraaaa. </div>

  </div>

</body>

</html>
